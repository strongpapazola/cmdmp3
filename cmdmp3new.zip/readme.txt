Please see the post "Update to a Command Line MP3 Player for Windows"
https://lawlessguy.wordpress.com/2015/06/27/update-to-a-command-line-mp3-player-for-windows/
